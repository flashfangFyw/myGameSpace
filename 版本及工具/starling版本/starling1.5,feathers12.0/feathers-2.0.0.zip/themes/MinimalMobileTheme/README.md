# Minimal Mobile Theme for Feathers

This [Feathers](http://feathersui.com/) theme for mobile devices combines simple gray colors with a retro pixel aesthetic.

## Credits

This theme is based on the appearance of [MinimalComps](http://minimalcomps.com/), a great set of Flash user interface components created by [Keith Peters](http://bit-101.com/). With permission, the theme was ported to Feathers by [Josh Tynjala](http://twitter.com/joshtynjala). This theme uses the free Ronda Seven font, designed by [Yusuke Kamiyamane](http://p.yusukekamiyamane.com/).