Transporter Chief
=================

*Notice: This tool works on OS X only.*

The "Transporter Chief" can deploy iOS apps directly to the iPhone or iPad via the command line. 
Find out all about the chief in [this article][1] on the Gamua blog.

[1]: http://gamua.com/blog/2012/03/how-to-deploy-ios-apps-to-the-iphone-via-the-command-line/
